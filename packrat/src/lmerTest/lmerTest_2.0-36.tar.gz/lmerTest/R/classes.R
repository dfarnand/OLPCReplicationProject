merModLmerTest <- setClass("merModLmerTest", contains = c("merMod", "lmerMod"))

  


